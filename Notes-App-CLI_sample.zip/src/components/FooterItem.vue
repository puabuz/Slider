
<template>
  <footer class="footer">
    <div class="container">
      <div class="navbar-list">
        <ul class="navbar-list">
          <li class="navbar-item" v-for="link in links" :key="link.alias">
            <router-link class="navbar-link" :to="link.url">{{ link.title }}</router-link>
          </li>
        </ul>
      </div>
    </div>
  </footer>
</template>
<script>

import {links} from '@/_config.js'

export default {
  data(){
    return{
      links,
    }
  }
};
</script>

<style lang="scss">
  
</style>