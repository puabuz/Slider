<template>
  <div>
    <h1>404</h1>
    <p>Not found</p>
  </div>
</template>

<script>
export default {
  name: 'notFound' 
}
</script>
