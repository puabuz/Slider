export default [
  {
    id: 1,
    alias: 'testAlias',
    title: 'testBarbarian',
    descr: 'testDescr',
    img: 'testImg',
  },
]
